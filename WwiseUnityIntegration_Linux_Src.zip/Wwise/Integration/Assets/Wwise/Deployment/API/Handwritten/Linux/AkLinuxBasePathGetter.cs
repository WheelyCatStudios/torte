﻿#if UNITY_STANDALONE_LINUX && !UNITY_EDITOR
public partial class AkBasePathGetter
{
	static string DefaultPlatformName = "Linux";
}
#endif